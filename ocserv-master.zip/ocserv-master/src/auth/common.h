#ifndef AUTH_COMMON_H
# define AUTH_COMMON_H

#define MAX_PASSWORD_TRIES 3

extern const char* pass_msg_second;
extern const char* pass_msg_otp;
extern const char* pass_msg_failed;

#endif
