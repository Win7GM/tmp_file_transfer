#!/bin/sh

autoreconf -fvi
